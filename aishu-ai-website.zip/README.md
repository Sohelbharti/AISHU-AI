# Aishu — Personal AI Assistant Website

This is the first frontend prototype for Aishu.

## Run
Open `index.html` in a browser, or use a local server:

- VS Code + Live Server
- `python -m http.server 5500`

## Important
The current chat uses demo responses. Do NOT put an OpenAI API key in `index.html`.
Next, connect this frontend to a secure Node.js backend, then connect the backend to the OpenAI API.
